function OutroComponente(){
    return (<h1>Outro Componente</h1>);
}

export default OutroComponente;