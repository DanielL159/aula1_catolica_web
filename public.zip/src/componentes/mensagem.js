function Mensagem (){
    return (
        <div>
            <h1>Boas Vindas</h1>
        </div>
    );
}

export default Mensagem;