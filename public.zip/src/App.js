
import React from'react';
import './App.css';
import OutroComponente from './componentes/OutroComponete';

import Mensagem from './componentes/mensagem';

function App() {
  return (
    <div>
      <Mensagem></Mensagem>
      <OutroComponente></OutroComponente>
    </div>
  );
}

export default App;
